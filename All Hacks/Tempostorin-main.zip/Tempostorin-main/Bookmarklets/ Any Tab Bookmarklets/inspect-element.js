(function () {var v = document.createElement('script');v.src = 'https://cdn.jsdelivr.net/gh/SnowLord7/devconsole@master/main.js';document.body.appendChild(v);}())
