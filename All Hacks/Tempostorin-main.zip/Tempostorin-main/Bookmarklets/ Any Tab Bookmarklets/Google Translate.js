javascript:var a="https://translate.google.com/translate?u=";var b=encodeURI(location.href);var c="?tl=en";open(a+b+c);
