//cached sites from google (could unblock?)

location.href='http://webcache.googleusercontent.com/search?q=cache:'+window.location.href
