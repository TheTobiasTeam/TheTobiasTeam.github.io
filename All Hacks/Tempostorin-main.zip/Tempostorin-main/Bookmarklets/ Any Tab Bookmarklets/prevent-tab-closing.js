//prevents tab closing

javascript:window.onbeforeunload = function() { return "Do your want to close"; }; alert("Tab Secured");
