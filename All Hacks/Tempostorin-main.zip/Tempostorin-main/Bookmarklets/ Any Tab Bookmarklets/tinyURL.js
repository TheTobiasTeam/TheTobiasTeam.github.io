javascript:void(open('http://tinyurl.com/create.php?url='+encodeURIComponent(location.href)))
