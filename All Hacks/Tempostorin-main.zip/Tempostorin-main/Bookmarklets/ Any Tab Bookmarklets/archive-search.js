//searches archive.org for selection

javascript: void(location.href = 'http://web.archive.org/web/*/' + prompt("Put URL (or search term) here, then press enter",window.getSelection()));
