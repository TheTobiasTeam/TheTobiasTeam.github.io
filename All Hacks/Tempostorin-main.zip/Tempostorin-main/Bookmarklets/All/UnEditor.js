javascript:document.body.contentEditable = 'false'; document.designMode='off'; void 0

