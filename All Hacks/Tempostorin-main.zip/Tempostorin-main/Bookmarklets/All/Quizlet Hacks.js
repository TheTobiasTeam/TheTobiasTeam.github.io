javascript:document.getElementsByClassName("UIButton UIButton--hero")[0].click(); setTimeout(function(){for(var F = setTimeout(";"), i = 0; i < F; i++) clearTimeout(i)}, 600); 
