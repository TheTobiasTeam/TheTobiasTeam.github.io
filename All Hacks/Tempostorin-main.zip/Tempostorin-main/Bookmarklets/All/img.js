/**
 * Defaults to Ecosia Images (see `eimg`).
 *
 * @title Image search
 * @keyword img
 * @transclude eimg.js
 */
