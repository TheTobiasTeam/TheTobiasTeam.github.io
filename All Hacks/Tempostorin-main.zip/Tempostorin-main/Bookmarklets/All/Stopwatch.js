javascript:(function(d,w,f,t,e){t=(e=w.elp$||0)?clearInterval(e,d.title=odT,elp$=0)&&0:f(w.elp$=setInterval(function(){d.title=(new Date(f()-t)).toISOString().substr(11,8)},40),w.odT=d.title)})(document,window,function(){return(new Date())|0});

