open("https://i.ytimg.com/vi/" + location.search.match(/v=([^&]+)/)[1] + "/maxresdefault.jpg");
