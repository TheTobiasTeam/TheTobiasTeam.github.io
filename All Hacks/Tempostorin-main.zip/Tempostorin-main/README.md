# Tempostorin

<div align="center">
  <img src="https://github.com/ilytobias/Khan-Destroyer/assets/165577429/fcd7fa24-a62c-46c8-bc02-78463bd4c64a" width="500" height="500"></img>

  (logo made by [orphanlol](https://github.com/orphanlol))

  ### Discord

  Join the **[Discord](https://discord.gg/pujbPqMyPF)** for support and information! Our community is welcome to friendly discussion about our bookmarklets.

  You can also provide suggestions.
</div>

## How to Use Bookmarklets

1. Select all of the code

2. Drag it to your bookmarks bar

3. Click when you want to run the bookmarklet

## Downloadable Games / Hacks
<p>
  Each downloadable game has a step-by-step tutorial on downloading and using it. There is also a quick tutorial.
</p>
<p>
 <br>
   1. Download the .zip file
  <br>
  2. Open the folder in the .zip file until you see an index.html file
  <br>
  3. Open the index.html file
  <br>
</p>

# About

## Safe?
Yes this is safe, there have been **zero** recorded cases of a account being banned for hacks (at least for now). <br>
Also if you're asking if this is a virus it is 100% open sourced forever so you can look through the code to see for yourself. <br>

## Support
Star the repo, or join the discord.
<br>
![image](https://github.com/ilytobias/Khan-Destroyer/assets/165577429/673061fc-c131-423b-a81b-daf862b96493)

